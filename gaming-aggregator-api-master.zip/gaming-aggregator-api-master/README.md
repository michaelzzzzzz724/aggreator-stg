# gaming-aggregator-api
api that aggregates data from different gaming services
