// @flow

require('../config/init');
require('./database/init');
require('./authentication/init');
